// Phase 2
// An implementation of MovieCollection ADT
// 2022


using System;

//A class that models a node of a binary search tree
//An instance of this class is a node in a binary search tree 
public class BTreeNode
{
	private IMovie movie; // movie
	private BTreeNode lchild; // reference to its left child 
	private BTreeNode rchild; // reference to its right child

	public BTreeNode(IMovie movie)
	{
		this.movie = movie;
		lchild = null;
		rchild = null;
	}

	public IMovie Movie
	{
		get { return movie; }
		set { movie = value; }
	}

	public BTreeNode LChild
	{
		get { return lchild; }
		set { lchild = value; }
	}

	public BTreeNode RChild
	{
		get { return rchild; }
		set { rchild = value; }
	}
}

// invariant: no duplicates in this movie collection
public class MovieCollection : IMovieCollection
{
	private BTreeNode root; // movies are stored in a binary search tree and the root of the binary search tree is 'root' 
	private int count; // the number of (different) movies currently stored in this movie collection 



	// get the number of movies in this movie colllection 
	// pre-condition: nil
	// post-condition: return the number of movies in this movie collection and this movie collection remains unchanged
	public int Number { get { return count; } }

	// constructor - create an object of MovieCollection object
	public MovieCollection()
	{
		root = null;
		count = 0;	
	}

	// Check if this movie collection is empty
	// Pre-condition: nil
	// Post-condition: return true if this movie collection is empty; otherwise, return false.
	public bool IsEmpty()
	{
		if (count == 0 && root == null)
		{
			Console.WriteLine("Database is empty");
			return true;
		}
		else {
			Console.WriteLine("Database is NOT empty");
			return false;
		}
	}
	// Insert a movie into this movie collection
	// Pre-condition: nil
	// Post-condition: the movie has been added into this movie collection
	public bool Insert(IMovie movie)
	{		if (Search(movie) == true) {
			Console.WriteLine("Item '"+ movie.Title + "' already in database");
			return false;
			}

            if (root == null)
            {
                root = new BTreeNode(movie);
                string printroot = root.Movie.Title;
                Console.WriteLine("Added " + movie.Title.ToString() + " to root node of " + printroot);
                return true;
            }
            else
            {
                bool val = Insert(movie, root);
                if (val == false)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
    }
	
	private bool Insert(IMovie movie, BTreeNode root)
	{
			if (root == null)
			{  // if root node empty
				root = new BTreeNode(movie); //add movie to root node
				count++;
				string printroot = root.Movie.Title;
				Console.WriteLine("Added " + movie.Title.ToString() + " to root node of " + printroot);
				return true; // return true 
			}
			else

				if (movie.CompareTo(root.Movie) < 0) // if less than root node
			{
				if (root.LChild == null)
				{ // and left child is empty	
					root.LChild = new BTreeNode(movie); // add movie to left node
					string printroot = root.Movie.Title;
					Console.WriteLine("Added " + movie.Title.ToString() + " to left node of " + printroot);
					count++;
					return true; // return true	
				}
				else // if left child is full
					 // set new root as left child
					Insert(movie, root.LChild); // call method again

			}
			else // if greater than root node
			{
				if (root.RChild == null)
				{ // and right child is empty
					root.RChild = new BTreeNode(movie); // add movie to right node
					string printroot = root.Movie.Title;
					Console.WriteLine("Added " + movie.Title.ToString() + " to right node of " + printroot);
					count++;
					return true; // return true
				}
				else // if left child is full
					Insert(movie, root.RChild); // call method again with right child node
			}
			return false; // could not add element

	}
		
	


	// Delete a movie from this movie collection
	// Pre-condition: nil
	// Post-condition: the movie is removed out of this BST, if it is in this BST
	public bool Delete(IMovie movie)
	{
		// search for item and its parent
		BTreeNode ptr = root; // search reference
		BTreeNode parent = null; // parent of root
		while ((ptr != null) && (movie.CompareTo(ptr.Movie) != 0)) // when there root is not null and the comparision is false
		{
			parent = ptr; // shift root to parent node
			if (movie.CompareTo(ptr.Movie) < 0) // if movie is less than 0
				ptr = ptr.LChild; // root becomes left child node
			else // if movie is greater than 0
				ptr = ptr.RChild; // root becomes right child node
		}

		if (ptr != null) // if  the item was found
		{

			if ((ptr.LChild != null) && (ptr.RChild != null)) // if root has two children existing
			{
				// find the right-most node in left subtree of root
				if (ptr.LChild.RChild == null) // if a right subtree of the left child doesnt exist
				{
					ptr.Movie = ptr.LChild.Movie; // move child to root status
					ptr.LChild = ptr.LChild.LChild; // move left grandchild to child status
					Console.WriteLine("1: Item " + movie.Title + " has been replaced with " + ptr.Movie.Title);
					count--;
					return true; // return true
				}
				else // if right subtree exists
				{
					BTreeNode p = ptr.LChild; // select root's left child and store in var p
					BTreeNode pp = ptr; // parent of root
					while (p.RChild != null) // find the right most child of p by going down right chain
					{
						pp = p; // left child becomes parent
						p = p.RChild; // right child moved into p position
					}
					// copy the item at p to ptr
					ptr.Movie = p.Movie; // replace root to be deleted with right most child of left subtree
					pp.RChild = p.LChild;
					Console.WriteLine("2: Item " + movie.Title + " has been replaced with " + p.Movie.Title);
					count--;
					return true;
				}
			}
			else // if one child exists 
			{
				BTreeNode child;
				if (ptr.LChild != null) // where a child exists
					child = ptr.LChild; // pick left child if exists
				else
					child = ptr.RChild; // pick right child

				// remove node ptr
				if (ptr == root) {  //need to change root
					root = child; // child becomes new root
					Console.WriteLine("3: Item '" + movie.Title + "' has been replaced with '" + root.Movie.Title + "'");
					count--;
					return true;
				}
				else
				{
					if (ptr == parent.LChild)
						parent.LChild = child;
					else
						parent.RChild = child;
					Console.WriteLine("Item '" + movie.Title + "' has been removed");
					count--;
					return true;
				}
			}
		}
		else { // if item not found
			Console.WriteLine("Item does not exist in the movie collection");
			return false;
		}
	}


	// Search for a movie in this movie collection
	// pre: nil
	// post: return true if the movie is in this movie collection;
	//	     otherwise, return false.
	public bool Search(IMovie movie)
	{
		if (Search(movie, root))
		{			
			return true;
		}
		else {		
			return false;
		}	
	}
	private bool Search(IMovie item, BTreeNode current)
	{
		if (current != null)
		{
			if (item.CompareTo(current.Movie) == 0)
				return true;
			else
				if (item.CompareTo(current.Movie) < 0)
				return Search(item, current.LChild);
			else
				return Search(item, current.RChild);
		}
		else
			return false;
	}
	private bool SearchTitle(string item, BTreeNode current)
	{
		if (current != null)
		{
			if (item.CompareTo(current.Movie.Title) == 0) {
				Console.WriteLine(item + " compared to " + current.Movie.Title);
				root  = current;
				return true;
				
			}
			else
				if (item.CompareTo(current.Movie.Title) < 0)
				return SearchTitle(item, current.LChild);
			else
				return SearchTitle(item, current.RChild);
		}
		else
			return false;
	}

	// Search for a movie by its title in this movie collection  
	// pre: nil
	// post: return the reference of the movie object if the movie is in this movie collection;
	//	     otherwise, return null.
	public IMovie Search(string movietitle)
	{
		BTreeNode current2 = root;
		BTreeNode current = root;
		if (SearchTitle(movietitle, current))

		{	
			BTreeNode save = root;
			root = current2;
			Console.WriteLine("Movie with title '" + save.Movie.Title + "' found in database");
			return save.Movie;
		}
		else
		{	
			Console.WriteLine("Movie with title '" + movietitle + "' NOT found in database");
			return null;
		}		
	}

	// Store all the movies in this movie collection in an array in the dictionary order by their titles
	// Pre-condition: nil
	// Post-condition: return an array of movies that are stored in dictionary order by their titles
	
	public IMovie[] ToArray()
	{	int i = 0;
		BTreeNode rootparent = root;
		IMovie[] array = new IMovie[count + 1];
		StoreInOrder(rootparent, array, i);
		return array;
	}



	private void StoreInOrder(BTreeNode iRoot, IMovie[] array, int i)
	{
		if (null != iRoot)
		{
			StoreInOrder(iRoot.LChild, array, i);
			i = nextnullspace(array, i);
			
			array[i] = iRoot.Movie;
			
			StoreInOrder(iRoot.RChild, array, i);

		}
	}
	private int nextnullspace (IMovie[] array, int i) {
		while (true) { 
			if (array[i] != null)
			{		
				i++;
			}
			else {	
				return i;
			}
		}
	}

	// Clear this BST
	// Pre-condotion: nil
	// Post-condition: all the movies have been removed from this movie collection 
	public void Clear()
	{	
		Console.WriteLine("Database cleared");
		root = null;
		count = 0;
	}
}





